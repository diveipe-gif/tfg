const https = require('https');

const BIN_ID = '6a16aafc8ef04f4538206602';
const API_KEY = '$2a$10$ZB6hMbOsX59xEJb3Z32hP.js/VVp3YtmWdyRc8B0PI3vy0ZF8xhGK';

function jsonbinRequest(method, data) {
  return new Promise((resolve, reject) => {
    const body = data ? JSON.stringify(data) : null;
    const options = {
      hostname: 'api.jsonbin.io',
      path: `/v3/b/${BIN_ID}`,
      method: method,
      headers: {
        'Content-Type': 'application/json',
        'X-Master-Key': API_KEY,
        'X-Bin-Versioning': 'false',
        ...(body ? {'Content-Length': Buffer.byteLength(body)} : {})
      }
    };
    const req = https.request(options, res => {
      let b = '';
      res.on('data', c => b += c);
      res.on('end', () => { try { resolve(JSON.parse(b)); } catch(e) { resolve({}); } });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

exports.handler = async (event) => {
  const h = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers: h, body: '' };

  if (event.httpMethod === 'POST') {
    try {
      const data = JSON.parse(event.body || '{}');
      const current = await jsonbinRequest('GET');
      let inbox = Array.isArray(current.record) ? current.record.filter(i => !i.init) : [];
      inbox.unshift({
        id: `${Date.now()}_${Math.random().toString(36).slice(2,6)}`,
        from: data.from || 'Gmail',
        subject: data.subject || 'Documento fiscal',
        date: data.date || new Date().toLocaleDateString('es-ES'),
        attachments: data.attachments || 0,
        analysis: data.analysis || '',
        timestamp: Date.now()
      });
      if (inbox.length > 50) inbox.splice(50);
      await jsonbinRequest('PUT', inbox);
      return { statusCode: 200, headers: h, body: JSON.stringify({ ok: true, total: inbox.length }) };
    } catch(e) {
      return { statusCode: 500, headers: h, body: JSON.stringify({ error: e.message }) };
    }
  }

  try {
    const result = await jsonbinRequest('GET');
    const inbox = Array.isArray(result.record) ? result.record.filter(i => !i.init) : [];
    const since = parseInt((event.queryStringParameters || {}).since || '0');
    const items = since > 0 ? inbox.filter(i => i.timestamp > since) : inbox;
    return { statusCode: 200, headers: h, body: JSON.stringify(items) };
  } catch(e) {
    return { statusCode: 200, headers: h, body: '[]' };
  }
};
