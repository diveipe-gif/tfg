const https = require('https');

const BIN_ID = '6a16aafc8ef04f4538206602';
const API_KEY = '$2a$10$ZB6hMbOsX59xEJb3Z32hP.js/VVp3YtmWdyRc8B0PI3vy0ZF8xhGK';

function jsonbinRequest(method, data) {
  return new Promise((resolve, reject) => {
    const body = data ? JSON.stringify(data) : null;
    const options = {
      hostname: 'api.jsonbin.io',
      path: `/v3/b/${BIN_ID}`,
      method: method,
      headers: {
        'Content-Type': 'application/json',
        'X-Master-Key': API_KEY,
        'X-Bin-Versioning': 'false',
        ...(body ? {'Content-Length': Buffer.byteLength(body)} : {})
      }
    };
    const req = https.request(options, res => {
      let b = '';
      res.on('data', c => b += c);
      res.on('end', () => { try { resolve(JSON.parse(b)); } catch(e) { resolve({}); } });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method === 'POST') {
    try {
      const data = req.body || {};
      const current = await jsonbinRequest('GET');
      let inbox = Array.isArray(current.record) ? current.record.filter(i => !i.init) : [];
      inbox.unshift({
        id: `${Date.now()}_${Math.random().toString(36).slice(2,6)}`,
        from: data.from || 'Gmail',
        subject: data.subject || 'Documento fiscal',
        date: data.date || new Date().toLocaleDateString('es-ES'),
        attachments: data.attachments || 0,
        analysis: data.analysis || '',
        timestamp: Date.now()
      });
      if (inbox.length > 50) inbox.splice(50);
      await jsonbinRequest('PUT', inbox);
      res.status(200).json({ ok: true, total: inbox.length });
    } catch(e) {
      res.status(500).json({ error: e.message });
    }
    return;
  }

  // GET
  try {
    const result = await jsonbinRequest('GET');
    const inbox = Array.isArray(result.record) ? result.record.filter(i => !i.init) : [];
    const since = parseInt(req.query?.since || '0');
    const items = since > 0 ? inbox.filter(i => i.timestamp > since) : inbox;
    res.status(200).json(items);
  } catch(e) {
    res.status(200).json([]);
  }
};
