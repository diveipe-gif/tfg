// Alias de webhook para el polling desde el frontend
exports.handler = async (event, context) => {
  // Redirigir a la función webhook
  const webhookFn = require('./webhook');
  return webhookFn.handler({ ...event, httpMethod: 'GET' }, context);
};
